package com.spring.shopping.model;

public class Rating {

}
