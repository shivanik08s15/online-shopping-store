package com.spring.shopping.repository.impl;

import com.spring.shopping.model.AddressForm;
import com.spring.shopping.repository.AddressRepository;

public class AddressRepositoryHibernateImpl implements AddressRepository {

	@Override
	public void saveAddress(AddressForm address) {

	}

	@Override
	public AddressForm readAddressById(Long addressId) {
		
		return null;
	}

}
