package com.spring.shopping.controller.constants;

public class ControllerConstants {
	public static final String CART = "cart";
	public static final String NUMBER_OF_ITEMS = "numberOfItems";
	public static final String CUSTOMER = "customer";
}
