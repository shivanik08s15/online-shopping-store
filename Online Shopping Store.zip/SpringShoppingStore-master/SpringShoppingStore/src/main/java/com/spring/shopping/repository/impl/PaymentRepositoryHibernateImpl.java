package com.spring.shopping.repository.impl;

import com.spring.shopping.model.CreditCardForm;
import com.spring.shopping.repository.PaymentRepository;

public class PaymentRepositoryHibernateImpl implements PaymentRepository {

	@Override
	public void payByCreditCard(CreditCardForm creditCardForm) {
		// TODO Auto-generated method stub

	}

}
